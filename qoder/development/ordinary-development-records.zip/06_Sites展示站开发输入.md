# 用 Qoder 制作“组会接力”公开展示站

这是本项目真实开发的一部分。主应用正由另一个 Qoder CLI 回合修复，本回合只编辑 `qoder/site/`，不要修改 app、tests、README、依赖、数据或其他题。不要提交或推送 Git，不调用子代理，不读取任何密钥或认证配置，不运行 pkill/killall。

请直接完成一个精致、中文、可离线构建的静态展示站，作为 Qoder Sites 的公开入口。使用原生 HTML/CSS/少量 JS 和 Python 标准库构建脚本即可，无需 npm 包或新费用。最终写入 site/src、site/build.py、site/README.md；生成输出到 site/dist，dist 被本项目忽略。

真实项目信息：

- 名称“组会接力”，将分散的进展、决定和下一步连接起来。面向课题组/课程项目，导入约定格式的 Markdown/CSV，创建任务，记录四项复盘，完成/编辑任务，修正与撤回复盘，生成有来源的周报/交接单。
- 运行时 Python3.12 / FastAPI0.115.14 / PowerContext1.4.1 builtin SQLite。PowerContext 保存项目事件、进展、决策、偏好；按真实 SDK 分页读取，用有效事件生成接续卡和报告。浏览器只缓存当前项目。应用无需 LLM 或额外账号。
- 主要业务、界面与 PowerContext 接入由 Qoder CN CLI1.1.81 开发。Codex 负责规格、环境、独立测试、发布核验和材料整理。不要声称所有代码都由 Qoder 写，也不要展示内部修复历史。
- 真实测试和截图仍在生成，网站不能写“已全部通过”或虚构数字。请让 `site/build.py` 接受 `--source-sha`（40位十六进制）、`--site-version`、`--facts` JSON 路径，从 facts 读取已核验检查条数、结论、截图清单。未给 facts 时应显示“验收记录见固定版本材料”，不要产生假结果。
- 暂无真人使用统计。自动化验收是固定虚构样例上的工具实验，不能当用户数/提效百分比。
- GitHub 仓库 https://github.com/Sunny1004-7/oceanbase-2026-powercontext ，分支2026-competition-ecosystem，资产在qoder/。公开站要链接固定版本的 README、样例、验证记录、开发记录，链接由 build.py 注入 source-sha，避免浮动main。代码入口用 https://github.com/Sunny1004-7/oceanbase-2026-powercontext/tree/{sha}/qoder 。
- 这是“公开展示站 + 本地可运行应用”。不要提供 localhost 公网体验链接，不要假装网页在读本地 PowerContext。若不做静态互动更好，把页面重点放在真实截图与可复现操作。

页面要求：

1. 清楚的首屏、真实痛点与三步流程（记录→接续→交接），静态圆角便签/时间线可用，但不要冒充真实产品截图。
2. 已完成功能和边界：约定格式输入、单机单进程、项目隔离、来源追溯、修正/撤回、偏好影响报告；不支持任意会议全文理解、云端多人协作。
3. “真实界面”图片区从 `site/assets/` 引用后续复制的真实应用截图（桌面总览、报告、移动界面），assets 不存在时显示明确“截图随发布版本补齐”，不得生成假截图；最终发布时由 Codex 加入已验收真图。
4. 技术分工，用容易理解的文字说明 PowerContext 如何保存/恢复有效记录，Qoder 做了什么。可用简洁 SVG/HTML 小图，但产品主流程不要夹带内部执行细节。
5. 运行方法和两个虚构样例，链接到固定版仓库的运行说明、`samples/验证样例.md`、`evidence/验收摘要.json`、`development/README.md`。
6. 页脚显示完整 source SHA、站点版本、当前为静态展示站、暂无真人使用统计。不能把未通过的检测写成通过。
7. 桌面与390px移动布局，无横向溢出；对比度、键盘焦点、语义标题、图片alt、简洁动效，prefers-reduced-motion生效。蓝黑墨色/暖白纸面、小面积青绿色。避免俗套大渐变球、全屏玻璃卡。

构建应把源码、assets和 facts 生成 `dist/index.html`、CSS/JS及所需资源，构建产物无外部运行依赖。禁止输出真实 API key、UID猜测或认证链接。输出已创建文件与构建命令，直接完成，不停在建议。
