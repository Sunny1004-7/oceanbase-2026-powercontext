const {chromium}=require('./浏览器工具/node_modules/playwright');const fs=require('fs');const path=require('path');
const root=__dirname,base='http://127.0.0.1:4324';
const run=process.argv[2]||new Date().toISOString().replace(/[^0-9]/g,'').slice(0,14);
const out=path.join(root,'原始证据','Qoder','browser-'+run);fs.mkdirSync(out,{recursive:true});
const checks=[],events=[],errors=[];let browser,context,p;
const check=(name,passed,detail)=>checks.push({name,passed:!!passed,...(detail?{detail}:{})});
async function idle(){await p.locator('#loading-overlay').waitFor({state:'hidden'});await p.waitForTimeout(150);}
async function write(click,part){const response=p.waitForResponse(r=>r.url().includes(part)&&r.request().method()!=='GET');await click();const r=await response;await idle();return r;}
async function jsonGet(url){const r=await context.request.get(base+url);if(!r.ok())throw Error('Read failed '+url);return r.json();}
async function state(scope){return jsonGet(`/api/projects/${scope}/state`);}
async function create(name){await p.locator('#btn-new-project').click();await p.locator('#new-project-name').fill(name);await write(()=>p.locator('#new-project-form button[type=submit]').click(),'/api/projects');const list=await jsonGet('/api/projects');return list.projects.find(x=>x.title===name).scope_id;}
async function tab(name){await p.locator(`[data-tab=${name}]`).click();}
async function report(){await tab('report');await p.locator('#btn-generate-report').click();await idle();return p.locator('#report-preview').innerText();}
async function screenshot(name,fullPage=false){await p.screenshot({path:path.join(out,name+'.png'),fullPage});}
async function finalRecord(extra={}){fs.writeFileSync(path.join(out,'results.json'),JSON.stringify({passed:checks.length>0&&checks.every(x=>x.passed)&&errors.length===0,run,base,checks,pageErrors:errors,events,...extra},null,2));}
(async()=>{
 browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'});
 context=await browser.newContext({viewport:{width:1440,height:1050},acceptDownloads:true});p=await context.newPage();p.on('pageerror',e=>errors.push(String(e)));
 p.on('response',async r=>{if(r.url().startsWith(base+'/api/')){let data;try{data=await r.json()}catch{data=await r.text().catch(()=>null)}events.push({path:r.url().slice(base.length),method:r.request().method(),status:r.status(),input:r.request().postData(),data});}});
 await p.goto(base,{waitUntil:'networkidle'});check('fresh browser opens with project list',await p.locator('#btn-new-project').isVisible());await screenshot('empty');
 const nameA=run==='release'?'海藻培养实验':'海藻培养实验 · '+run.slice(-6),nameB=run==='release'?'课程协作工具':'课程协作工具 · '+run.slice(-6);const A=await create(nameA);
 const emptyReport=await report();check('empty project report invents no progress',emptyReport.includes('暂无记录')&&!emptyReport.includes('配制'));
 await tab('import');check('example import is visible for selected project',await p.locator('#btn-load-algae').isVisible());
 await write(()=>p.locator('#btn-load-algae').click(),'/import');const first=await state(A);check('sample Markdown import through UI',first.tasks.length>0&&first.reviews.length>0&&first.tasks.some(t=>t.title.includes('蓝光灯')),{tasks:first.tasks.length,reviews:first.reviews.length});
 check('a record change invalidates the earlier report export',await p.locator('#btn-download-report').isDisabled());
 await write(()=>p.locator('#btn-load-algae').click(),'/import');const duplicate=await state(A);check('repeat example creates no duplicate effective tasks',JSON.stringify(first.tasks)===JSON.stringify(duplicate.tasks)&&JSON.stringify(first.reviews)===JSON.stringify(duplicate.reviews));
 const card=await p.locator('#continuation-content').innerText();check('continuation displays actual source IDs',first.tasks.filter(t=>t.status!=='done').every(t=>card.includes(t.source_id)));
 check('continuation provides timestamp and original entry',await p.locator('#continuation-content time[datetime]').count()>0&&await p.locator('#continuation-content button').count()>0);
 await p.locator('#continuation-content button').first().click();await p.locator('#source-modal').waitFor({state:'visible'});check('continuation opens real source', (await p.locator('#source-detail-content').innerText()).includes(first.tasks[0].source_id));await screenshot('source-detail');await p.locator('#source-modal .modal-close').click();
 await tab('tasks');const tid=first.tasks[0].id;let row=p.locator('.task-row').filter({has:p.locator(`[data-task-id="${tid}"]`)});row=p.locator(`.task-row[data-task-id="${tid}"]`);
 await write(()=>row.locator('[data-act=complete]').click(),'/tasks/');
 const edits=['蓝光灯标定（已核准）','小禾','2026-11-03'];let dialogIndex=0;const dialogs=async d=>{if(d.type()==='prompt')await d.accept(edits[dialogIndex++]);else await d.accept();};p.on('dialog',dialogs);
 await write(()=>p.locator(`.task-row[data-task-id="${tid}"] [data-act=edit]`).click(),'/tasks/');
 let s=await state(A),task=s.tasks.find(t=>t.id===tid);check('complete and edit task through UI',task.status==='done'&&task.title===edits[0]&&task.owner===edits[1]);
 await p.locator(`.task-row[data-task-id="${tid}"] [data-act=source]`).click();await p.locator('#source-modal').waitFor({state:'visible'});const sourceText=await p.locator('#source-detail-content').innerText();check('task current values cite the update source',sourceText.includes(task.source_id)&&sourceText.includes(edits[0]));await p.locator('#source-modal .modal-close').click();
 await tab('review');const rid='ui-review-'+run;await p.locator('#review-record-id').fill(rid);await p.locator('#review-date').fill('2026-10-31');await p.locator('#review-completed').fill('本周完成培养基校验');await p.locator('#review-blockers').fill('温控重复性待核对');await p.locator('#review-decisions').fill('先做同批次对照');await p.locator('#review-next-steps').fill('核对三组平行样');
 await write(()=>p.locator('#review-submit-btn').click(),'/reviews');
 const reviewRow=()=>p.locator(`.review-item[data-record-id="${rid}"]`);await reviewRow().locator('[data-act=correct]').click();await p.locator('#review-completed').fill('修正后：已完成两组，第三组待复核');await write(()=>p.locator('#review-submit-btn').click(),'/correct');
 s=await state(A);check('correction replaces earlier effective fact',s.reviews.some(r=>r.record_id===rid&&r.completed.includes('修正后')));
 const withdrawn=first.reviews[first.reviews.length-1].record_id;await p.locator(`.review-item[data-record-id="${withdrawn}"] [data-act=withdraw]`).click();await idle();s=await state(A);check('withdrawal removes effective review',!s.reviews.some(r=>r.record_id===withdrawn));
 await tab('preferences');await p.locator('#pref-report-title').fill('海藻培养实验 · 交接单');await p.locator('#pref-focus').selectOption('next_steps');await write(()=>p.locator('#preferences-form button[type=submit]').click(),'/preferences');
 const reportA=await report();check('report reflects stored preference and effective corrections',reportA.startsWith('# 海藻培养实验 · 交接单')&&reportA.indexOf('## 下一步')<reportA.indexOf('## 已完成')&&reportA.includes('修正后：已完成两组')&&!reportA.includes(withdrawn));
 check('report exposes source time and actual raw links',reportA.includes(`/api/projects/${A}/sources/`)&&reportA.includes(task.updated_at));await screenshot('report',true);
 const downloadEvent=p.waitForEvent('download');await p.locator('#btn-download-report').click();const dl=await downloadEvent;await dl.saveAs(path.join(out,'交接单.md'));check('Markdown download equals generated report',fs.readFileSync(path.join(out,'交接单.md'),'utf8').replace(/\r\n/g,'\n')===reportA.replace(/\r\n/g,'\n'));
 const B=await create(nameB);await tab('report');const switchedPreview=await p.locator('#report-preview').innerText();check('switching project clears previous report',!switchedPreview.includes('海藻培养实验 · 交接单')&&!switchedPreview.includes('修正后：已完成两组'));
 await tab('import');await p.locator('#import-format').selectOption('csv');const csv='record_id,date,completed,blockers,decisions,next_steps,task_id,title,status,owner,due_date\ncourse-week,2026-10-31,"完成接口,补齐说明",网络待检查,先交付离线版,验证导出,course-export,验证课程导出,todo,小叶,2026-11-04\n';const csvPath=path.join(out,'course.csv');fs.writeFileSync(csvPath,csv);await p.locator('#import-file').setInputFiles(csvPath);await write(()=>p.locator('#btn-import').click(),'/import');
 const stateB=await state(B);check('CSV file import keeps quoted values and project isolation',stateB.tasks.length===1&&stateB.reviews[0].completed==='完成接口,补齐说明'&&!(await state(A)).tasks.some(t=>t.id==='course-export'));
 const beforeBad=await state(B);await p.locator('#import-file').setInputFiles([]);await p.locator('#import-content').fill('record_id,task_id,title,status\nbad,row,非法状态,BAD');const badResponse=await write(()=>p.locator('#btn-import').click(),'/import');check('bad import produces visible error without partial write',badResponse.status()===400&&JSON.stringify(await state(B))===JSON.stringify(beforeBad)&&await p.locator('#toast.error').isVisible());
 const reportB=await report();check('second project report contains only its facts',reportB.includes('验证课程导出')&&!reportB.includes('蓝光灯标定')&&!reportB.includes('海藻培养实验 · 交接单'));
 await p.locator(`.project-item[data-scope-id="${A}"]`).click();await idle();await tab('tasks');await screenshot('desktop-overview',true);const finalA=await state(A),finalB=await state(B);
 await finalRecord({browserVersion:browser.version(),projects:{A:{scope:A,name:nameA,state:finalA,report:reportA},B:{scope:B,name:nameB,state:finalB,report:reportB}}});
 const mobile=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});const mp=await mobile.newPage();mp.on('pageerror',e=>errors.push(String(e)));await mp.goto(base,{waitUntil:'networkidle'});await mp.locator(`.project-item[data-scope-id="${A}"]`).click();await mp.locator('#loading-overlay').waitFor({state:'hidden'});
 const dimensions=await mp.evaluate(()=>({scroll:document.documentElement.scrollWidth,viewport:innerWidth}));check('390px layout has no horizontal page overflow',dimensions.scroll<=dimensions.viewport,dimensions);await mp.screenshot({path:path.join(out,'mobile.png')});await mp.screenshot({path:path.join(out,'mobile-full.png'),fullPage:true});await mobile.close();
 await finalRecord({browserVersion:browser.version(),projects:{A:{scope:A,name:nameA,state:finalA,report:reportA},B:{scope:B,name:nameB,state:finalB,report:reportB}}});
 await context.close();await browser.close();console.log(JSON.stringify({passed:checks.every(x=>x.passed)&&errors.length===0,checks,pageErrors:errors,out}));if(!checks.every(x=>x.passed)||errors.length)process.exitCode=1;
})().catch(async e=>{await finalRecord({fatal:String(e),stack:e.stack});console.error(e);if(browser)await browser.close();process.exitCode=1});
