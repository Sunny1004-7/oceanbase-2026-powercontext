"""Install the delivered Qoder app in an independent Linux source directory."""
import argparse,datetime,hashlib,json,os,pathlib,shutil,subprocess
ROOT=pathlib.Path(__file__).resolve().parent;SOURCE=ROOT/'生态工作区/qoder';DEST=pathlib.Path('/home/powercontext/r13/e03-clean-code');OUT=ROOT/'原始证据/Qoder'
p=argparse.ArgumentParser();p.add_argument('mode',choices=['init','sync','test']);p.add_argument('--label',default='');a=p.parse_args()
run_label=a.mode+('-'+a.label if a.label else '')
excluded={'.venv','venv','node_modules','__pycache__','.pytest_cache','.qoder','.git','.dev-archive','data','dist','development','evidence'}
records=[]
if a.mode in ('init','sync'):
 if a.mode=='init' and DEST.exists():raise RuntimeError('Existing clean directory is preserved; use sync after review')
 DEST.mkdir(parents=True,exist_ok=True)
 for directory,dirs,files in os.walk(SOURCE):
  dirs[:]=[d for d in dirs if d not in excluded and not d.startswith('data-')]
  for name in files:
   if name.startswith(('.env','.runtime')) or name in ('.qoder.site','test_api.py','test_comprehensive.py','test-fixes.sh','test-final.sh'):continue
   src=pathlib.Path(directory)/name;rel=src.relative_to(SOURCE);dest=DEST/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
   records.append({'path':rel.as_posix(),'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'copied_equal':src.read_bytes()==dest.read_bytes()})
 (OUT/'clean-source-manifest.json').write_text(json.dumps({'source':str(SOURCE),'target':str(DEST),'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':records},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
commands=[]
if a.mode=='init':commands=[['bash','scripts/setup.sh']]
elif a.mode=='test':commands=[[str(DEST/'.venv/bin/python'),'tests/independent_contract.py'],[str(DEST/'.venv/bin/python'),'tests/edge_contract.py'],[str(DEST/'.venv/bin/python'),'tests/lifecycle_contract.py'],[str(DEST/'.venv/bin/python'),'scripts/verify_runtime.py']]
results=[]
for index,cmd in enumerate(commands):
 label=run_label+'-'+str(index+1);log=OUT/('clean-'+label+'.log');start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with log.open('w') as f:run=subprocess.run(cmd,cwd=DEST,stdout=f,stderr=subprocess.STDOUT)
 results.append({'command':cmd,'cwd':str(DEST),'exit_code':run.returncode,'started_at_utc':start,'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 print(json.dumps(results[-1],ensure_ascii=False),flush=True)
 if run.returncode:break
(OUT/('clean-'+run_label+'-commands.json')).write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
if a.mode=='test':
 for rel in ['independent/results.json','independent/server.log','edge/results.json','edge/server.log','lifecycle/results.json','lifecycle/server.log','runtime-results.json','runtime-server.log','runtime-second.log']:
  src=DEST/'evidence'/rel
  if src.exists():
   dst=OUT/('clean-results'+('-'+a.label if a.label else ''))/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
raise SystemExit(0 if all(r['exit_code']==0 for r in results) else 1)
