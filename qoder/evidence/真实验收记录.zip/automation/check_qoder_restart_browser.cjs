const {chromium}=require('./浏览器工具/node_modules/playwright');const fs=require('fs');const path=require('path');
const root=__dirname,raw=path.join(root,'原始证据','Qoder'),label=process.argv[2]||'final-02',fixture=JSON.parse(fs.readFileSync(path.join(raw,'browser-'+label,'results.json'),'utf8')),base=fixture.base;
(async()=>{
const before=JSON.parse(fs.readFileSync(path.join(raw,'ui-runtime-before-restart.json'),'utf8')),after=JSON.parse(fs.readFileSync(path.join(raw,'ui-runtime-local.json'),'utf8'));
const checks=[{name:'new process uses the independent installed source and same data',passed:before.pid!==after.pid&&after.clean_install===true&&before.data===after.data&&before.app_dir===after.app_dir}];
const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'}),errors=[];
for(const [key,f] of Object.entries(fixture.projects)){
 const context=await browser.newContext({viewport:{width:1360,height:980}});const p=await context.newPage();p.on('pageerror',e=>errors.push(String(e)));
 await p.goto(base,{waitUntil:'networkidle'});const cached=await p.evaluate(()=>localStorage.getItem('lastProject'));checks.push({name:key+' fresh context has no project-state cache',passed:cached===null});
 await p.locator(`.project-item[data-scope-id="${f.scope}"]`).click();await p.locator('#loading-overlay').waitFor({state:'hidden'});
 const state=await (await context.request.get(base+`/api/projects/${f.scope}/state`)).json();checks.push({name:key+' persistent effective state is byte-equivalent after restart',passed:JSON.stringify(state)===JSON.stringify(f.state)});
 await p.locator('[data-tab=report]').click();await p.locator('#btn-generate-report').click();await p.locator('#loading-overlay').waitFor({state:'hidden'});await p.waitForTimeout(100);
 const report=await p.locator('#report-preview').innerText();checks.push({name:key+' UI report is reconstructed from saved sources',passed:report===f.report});
 await p.screenshot({path:path.join(raw,'restart-project-'+key+'.png'),fullPage:true});await context.close();
}
await browser.close();const result={passed:checks.every(x=>x.passed)&&errors.length===0,checks,pageErrors:errors,beforePID:before.pid,afterPID:after.pid,data:after.data,appDir:after.app_dir};fs.writeFileSync(path.join(raw,'browser-restart-'+label+'-results.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));if(!result.passed)process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1});
