const {chromium}=require('./浏览器工具/node_modules/playwright');const fs=require('fs');const path=require('path');const crypto=require('crypto');
const root=__dirname,url=process.argv[2],sha=process.argv[3],phase=process.argv[4]||'published',out=path.join(root,'原始证据','Qoder','site-'+phase);
(async()=>{
fs.mkdirSync(out,{recursive:true});const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'}),checks=[],errors=[],network=[];
for(const [label,viewport] of [['desktop',{width:1440,height:1000}],['mobile',{width:390,height:844}]]){
 const context=await browser.newContext({viewport});const p=await context.newPage();p.on('pageerror',e=>errors.push({label,error:String(e)}));p.on('response',r=>{if(r.status()>=400)network.push({url:r.url(),status:r.status()})});
 const response=await p.goto(url,{waitUntil:'networkidle'});checks.push({name:label+' anonymous HTTP success',passed:response.status()===200,finalUrl:p.url()});
 const text=await p.locator('body').innerText();checks.push({name:label+' expected project, source SHA and truthful usage disclosure',passed:text.includes('组会接力')&&text.includes(sha)&&text.includes('暂无真人使用统计')&&text.includes('r13-e03-v1')});
 const images=p.locator('img');for(let i=0;i<await images.count();i++){await images.nth(i).scrollIntoViewIfNeeded();await images.nth(i).evaluate(img=>img.complete?Promise.resolve():new Promise(resolve=>{img.onload=resolve;img.onerror=resolve}));}
 const broken=await p.locator('img').evaluateAll(imgs=>imgs.filter(i=>!i.complete||i.naturalWidth===0).map(i=>i.src));checks.push({name:label+' three real screenshots load',passed:await images.count()===3&&broken.length===0,broken});
 const dims=await p.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth}));checks.push({name:label+' no horizontal overflow',passed:dims.scroll<=dims.width,dimensions:dims});
 const links=await p.locator('a[href]').evaluateAll(xs=>xs.map(x=>({text:x.innerText,href:x.href})));checks.push({name:label+' code links use the immutable source version',passed:links.filter(x=>x.href.startsWith('https://github.com/Sunny1004-7/')).every(x=>x.href.includes(sha))&&links.some(x=>x.href.includes('/qoder/development/README.md'))});
 checks.push({name:label+' no local machine link offered as public experience',passed:!links.some(x=>/https?:\/\/(localhost|127\.0\.0\.1)/.test(x.href)&&!x.href.startsWith(url))});
 const badAnchors=await p.locator('a[href^="#"]').evaluateAll(xs=>xs.filter(x=>x.hash&&x.hash!=='#'&&!document.getElementById(decodeURIComponent(x.hash.slice(1)))).map(x=>x.hash));checks.push({name:label+' navigation anchor targets exist',passed:badAnchors.length===0,badAnchors});
 await p.evaluate(()=>scrollTo(0,0));await p.screenshot({path:path.join(out,label+'.png'),fullPage:true});fs.writeFileSync(path.join(out,label+'-links.json'),JSON.stringify(links,null,2));
 if(phase==='published'&&label==='desktop'){
  const files=['index.html','style.css','site.js','assets/desktop-overview.png','assets/report.png','assets/mobile.png'],bytes=[];
  for(const file of files){const r=await context.request.get(new URL(file,url.endsWith('/')?url:url+'/').href);const data=await r.body(),local=fs.readFileSync(path.join(root,'生态工作区/qoder/site/dist',file));const row={file,status:r.status(),sha256:crypto.createHash('sha256').update(data).digest('hex'),expected_sha256:crypto.createHash('sha256').update(local).digest('hex'),equal:data.equals(local)};
   if(file==='index.html'&&!row.equal){const text=data.toString('utf8'),tags=text.match(/<script data-qoder-watermark="v1"[^>]*>[\s\S]*?<\/script>/g)||[];if(tags.length===1&&crypto.createHash('sha256').update(tags[0]).digest('hex')==='f5049f24312d8eb94c51fff9bb97fe05e4114f51cf7c484ce8dc646625d6e64f'){row.hosting_watermark_only=Buffer.from(text.replace(tags[0],''),'utf8').equals(local);row.watermark_sha256='f5049f24312d8eb94c51fff9bb97fe05e4114f51cf7c484ce8dc646625d6e64f';}}
   bytes.push(row);}
  fs.writeFileSync(path.join(out,'published-bytes.json'),JSON.stringify(bytes,null,2));checks.push({name:'published assets match build; HTML has only the verified Qoder hosting watermark',passed:bytes.every(x=>x.status===200&&(x.equal||x.hosting_watermark_only)),files:bytes.length});
 }
 await context.close();
}
await browser.close();const result={passed:checks.every(x=>x.passed)&&errors.length===0&&network.length===0,phase,url,sha,checks,pageErrors:errors,networkErrors:network,browser:'Chrome156.0.8078.74 / Playwright1.56.1',anonymous:true};fs.writeFileSync(path.join(out,'results.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));if(!result.passed)process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1});
